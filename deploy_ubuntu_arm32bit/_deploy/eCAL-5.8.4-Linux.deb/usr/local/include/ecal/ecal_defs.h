#ifndef ecal_defs_h_included
#define ecal_defs_h_included
#define ECAL_VERSION_MAJOR (5)
#define ECAL_VERSION_MINOR (8)
#define ECAL_VERSION_PATCH (4)
#define ECAL_VERSION "v5.8.4-36-gffad8a5e-dirty"
#define ECAL_DATE "11.05.2021"
#define ECAL_PLATFORMTOOLSET ""

#define ECAL_INSTALL_APP_DIR     "bin"
#define ECAL_INSTALL_SAMPLES_DIR "bin"
#define ECAL_INSTALL_LIB_DIR     "lib"
#define ECAL_INSTALL_CONFIG_DIR  "etc/ecal"
#define ECAL_INSTALL_INCLUDE_DIR "include"
#define ECAL_INSTALL_PREFIX      "/usr/local"

#endif // ecal_defs_h_included
